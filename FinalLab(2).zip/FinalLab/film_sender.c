/*
 ============================================================================
 Name        : UDP.c
 Author      :
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>
#include <string.h>
#include <signal.h>

#define BFZ 1024
#define PREMIUM 0xFF
#define BASIC	0X7F
#define WAITING 0

struct arguments {
	uint32_t address;
	uint16_t port;
	uint8_t id;
	char* name;
};
int EXIT = 0;
int P_EXIT[2] = { 0, 0 };
int UDP_EXIT=0;
int PREMIUM_COUNT = 0;
int PREMIUM_COUNTER = 0;
float P_SPEED[2] = { 0, 0 };
int done = 1;
int exitset[2];
int play = 1;
fd_set* r_fds;
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
char* movies[2];
void* exit_trigger(){
	char c[2]={'\0'};
	//close(exitset[0]);
	printf("Press q to quit\n");

	while(EXIT==0){
		c[0] = getc(stdin);
		switch(c[0]){
		case 'q':
			printf("Exiting\n");
			EXIT=1;
			write(exitset[1],"1",1);

			break;
		default:
			break;
		}
	}
}
void* udp_channel(void* args) {
	struct arguments *arg = (struct arguments*) args;
	int UDPsocket, buffer;
	int count = 0;
	int retval = 0, retval2 = 0;
	int file = 0;
	unsigned int delay = 0;
	unsigned char ttl = 6;
	size_t size = BFZ;
	char c = '\0';
	int col = 0;
	int row = 0;
	char *buff;
	int bufferoffset;
	//int count=0;
	struct sockaddr_in serveraddr;
	socklen_t len = sizeof(serveraddr);

	buff = (char*) malloc((BFZ + 1) * sizeof(char));
	memset(buff, '\0', sizeof(buff));
	//buffer=atoi(args[3]);
	UDPsocket = socket(AF_INET, SOCK_DGRAM, 0);
	if (UDPsocket == -1) {
		printf("cant connect to socket\n");
		EXIT=1;
	}
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = arg->address;
	serveraddr.sin_port = arg->port;
	//printf("%d,%d\n", arg->address, arg->port);
	//printf("Multicast group: %s\nPort: %d\n", inet_ntoa(serveraddr.sin_addr),
	//(arg->port));
	retval = setsockopt(UDPsocket, IPPROTO_IP, IP_MULTICAST_TTL, &ttl,
			sizeof(ttl));
	if (retval == -1) {
		perror("setting error\n");
		EXIT=1;
	}
	while (EXIT == 0) {
		file = open(arg->name, O_RDONLY);
		if (file == -1) {
			close(UDPsocket);
			perror("cant open file\n");
			EXIT=1;
		}
		retval2 = 0;
		retval = read(file, &c, 1);
		row = 0;
		col = 0;
		while (c != '\n') {
			if (c == ',') {
				retval2 = 1;
			} else {
				switch (retval2) {
				case 0:
					row = row * 10 + (c - '0');
					break;
				case 1:
					col = col * 10 + (c - '0');
					break;
				}
			}
			retval = read(file, &c, 1);
		}
		row = row - 1;
		//col=col;
		size = (row) * col;
		buff = (char*) realloc(buff, ((col + 1) * (row + 1) * sizeof(char)));
		memset(buff, '\0', sizeof(buff));
		retval = 1;
		delay = 0;
		bufferoffset = 0;
		while ((retval = read(file, &c, 1)) > 0 && c != EOF) {
			while (c != '\n' && c >= '0' && c <= '9') {
				delay = delay * 10 + (c - '0');
				retval2 = read(file, &c, 1);
				if (retval == -1) {
					perror("read error\n");
				}
			}
			//printf("\n%d\n\n", delay);
			memset(buff, '\0', sizeof(buff));
			count = 0;
			bufferoffset = 0;

			c = '\0';
			for (count = 0; count < row && c != EOF; count++) { //print the frame
				c = '\0';
				while (c != '\n' && c != EOF) {
					buff[0] = '\n';
					retval = read(file, &c, 1);
					if (retval < 0) {
						perror("readerror\n");
					} else if (retval == 0) {
						c = EOF;
						bufferoffset++;
						buff[bufferoffset] = '\n';
					} else {
						bufferoffset += retval;
						buff[bufferoffset] = c;
					}
				}
			}
			bufferoffset++;
			buff[bufferoffset] = '\n';
			/*retval = read(file, &(buff[bufferoffset]), 1);
			 bufferoffset+=retval;*/
			//count++;
			if (retval == -1) {
				perror("read failed\n");
				EXIT=1;
			}
			//printf("\n%s\n", (buff));
			retval2 = sendto(UDPsocket, buff, bufferoffset, 0,
					(struct sockaddr*) &serveraddr, len);
			if (retval2 == -1) {
				perror("send failed\n");
				EXIT=1;
			}
			usleep(delay * 1000000 / 24);
			count += retval2;
			delay = 0;
		}
		//printf("\nEOF\n");
		close(file);
	}
	//printf("%d\n", count);
	close(UDPsocket);
	//close(file);
	if (retval == -1) {
		perror("read failed\n");
	}
	EXIT = 1;
	UDP_EXIT++;
	return &EXIT;
}

void* premium_connection(void* args) {
	struct arguments *arg = (struct arguments*) args;
	int TCPsocket, TCPClient, buffer;
	int count = 0;
	//int error=0;
	int file = 0;
	int retval = 0, retval2 = 0;
	socklen_t len;
	size_t size = BFZ;
	int delay = 0;
	char c = '\0';
	int row = 0;
	int col = 0;
	int bufferoffset = 0;
	char* buff;
	buff = (char*) malloc((BFZ + 1) * sizeof(char));
	memset(buff, '\0', sizeof(buff));
	struct sockaddr_in serveraddr, client;

	TCPsocket = socket(AF_INET, SOCK_STREAM, 0);
	//printf("1\n");
	if (TCPsocket == -1) {
		perror("cant connect to socket\n");
		//EXIT=1;
	}
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = arg->address;
	serveraddr.sin_port = (arg->port);
	//printf("%d,%d\n",arg->address,arg->port);
	//printf("2\n");
	if (bind(TCPsocket, (struct sockaddr*) &serveraddr, sizeof(serveraddr))
			!= 0) {
		close(TCPsocket);
		perror("cant bind to socket\n");
		//EXIT=1;
	}
	done = 1;
	//printf("3\n");
	if (listen(TCPsocket, 3) != 0) {
		close(TCPsocket);
		perror("cant listen to socket\n");
		//EXIT=1;
	}
	len = sizeof(client);

	TCPClient = accept(TCPsocket, (struct sockaddr*) &client, &len);
	//printf("socket number is %d\n",TCPClient);
	if (TCPClient < 0) {
		close(TCPsocket);
		perror("cant accept socket\n");
		//exit(0);
	}
	//printf("5\n");
	while (P_EXIT[arg->id] == 0) {
		done = 0;
		file = open(movies[arg->id], O_RDONLY);
		if (file == -1) {
			close(TCPsocket);
			perror("cant open file\n");
			//EXIT=1;
		}
		retval2 = 0;
		retval = read(file, &c, 1);
		row = 0;
		col = 0;
		while (c != '\n') {
			if (c == ',') {
				retval2 = 1;
			} else {
				switch (retval2) {
				case 0:
					row = row * 10 + (c - '0');
					break;
				case 1:
					col = col * 10 + (c - '0');
					break;
				}
			}
			retval = read(file, &c, 1);
		}
		row = row - 1;
		//col=col;
		size = (row) * col;
		buff = (char*) realloc(buff, ((col + 1) * (row + 1) * sizeof(char)));
		memset(buff, '\0', sizeof(buff));
		retval = 1;
		delay = 0;
		bufferoffset = 0;
		while ((retval = read(file, &c, 1)) > 0 && c != EOF && P_EXIT[arg->id] == 0 ) {
			while (c != '\n' && c >= '0' && c <= '9' && P_EXIT[arg->id] == 0) {
				delay = delay * 10 + (c - '0');
				retval2 = read(file, &c, 1);
				if (retval == -1) {
					perror("read error\n");
					P_EXIT[arg->id] = 1;
				}
			}
			//printf("\n%d\n\n", (int)(delay*P_SPEED[arg->id]/24));
			memset(buff, '\0', sizeof(buff));
			//printf("\n123\n");
			count = 0;
			bufferoffset = 0;

			c = '\0';
			for (count = 0; count < row && c != EOF && P_EXIT[arg->id] == 0; count++) { //print the frame
				c = '\0';
				buff[0] = '\n';
				while (c != '\n' && c != EOF && P_EXIT[arg->id] == 0) {

					retval = read(file, &c, 1);
					if (retval < 0) {
						perror("readerror\n");
						P_EXIT[arg->id] = 1;
					} else if (retval == 0) {
						c = EOF;
						bufferoffset++;
						buff[bufferoffset] = '\n';
					} else {
						bufferoffset += retval;
						buff[bufferoffset] = c;
					}
				}
			}
			bufferoffset++;
			buff[bufferoffset] = '\n';
			/*retval = read(file, &(buff[bufferoffset]), 1);
			 bufferoffset+=retval;*/
			//count++;
			if (retval == -1) {
				perror("read failed\n");
				P_EXIT[arg->id] = 1;
				//EXIT=1;
			}
			//printf("\n%s\n", (buff));
			//printf("stuck at send\n");
			retval2 = sendto(TCPClient, buff, bufferoffset, 0,
					(struct sockaddr*) &serveraddr, len);
			if (retval2 == -1) {
				perror("send failed\n");
				P_EXIT[arg->id] = 1;
				//close(TCPsocket);
			}
			usleep((int) (delay * 1000000 / (1+P_SPEED[arg->id]) / 24));
			count += retval2;
			delay = 0;
		}
		//printf("\nEOF\n");
		close(file);
		pthread_mutex_lock(&lock);
		done = 1;


		while (play != 1) {
			pthread_cond_wait(&cond, &lock);
		}
		pthread_mutex_unlock(&lock);

	}
	P_EXIT[arg->id] = 0;
	//printf("%d\n", count);
	//close(file);
	if (retval == -1) {
		perror("read failed\n");
	}
	done=1;
	//printf("7\n");
	//printf("%d\n", count);
	close(TCPsocket);
	//close(file);
	return &EXIT;
}

int main(int argc, char **argv) {
	int UDPcount = argc - 5;
	pthread_t* udp_channels = NULL;
	pthread_t premium_channels[2];
	pthread_t exit_thread;
	uint16_t stations;
	uint16_t station;
	int opt = 1;
	int channel[30];
	int client[50][5];
	size_t addrlen;
	fd_set readfds;
	uint8_t Welcome[11] = { 0 };
	uint8_t Announce[4] = { 0 };
	uint8_t ack[2] = { 0 };
	uint8_t Invalidp[2] = { 0 };
	struct sockaddr_in address;
	int basic_TCP;
	int clients, maxclient;
	int i = 0;
	int client_count = 50;
	int active;
	int connection;
	int state;
	struct arguments* arg;
	struct arguments p_arg[2];
	uint8_t clientmessage[4] = { 0 };
	uint8_t* row;
	uint8_t* col;
	int file;
	uint32_t multicastAddress;
	uint16_t port;
	char c = '\0';
	int retval, retval2;
	row = (uint8_t*) malloc(UDPcount * sizeof(uint8_t));
	col = (uint8_t*) malloc(sizeof(uint8_t) * UDPcount);
	row = memset(row, 0, sizeof(row));
	col = memset(col, 0, sizeof(col));

	for (i = 0; i < UDPcount; i++) {
		c = '\0';
		file = open(argv[5 + i], O_RDONLY);
		if (file == -1) {
			printf("%s\n", argv[5 + i]);
			perror("file\n");
		}
		retval2 = 0;
		//bufferoffset=0;
		arg = (struct arguments*) malloc(sizeof(struct arguments) * UDPcount);
		while (c != '\n') {
			retval = read(file, &c, 1);
			if (c == ',') {
				retval2 = 1;
			} else {
				switch (retval2) {
				case 0:
					row[i] = row[i] * 10 + (c - '0');
					break;
				case 1:
					col[i] = col[i] * 10 + (c - '0');
					break;
				}
			}
		}

		close(file);
	}
	multicastAddress = inet_addr(argv[3]);
	port = htons(atoi(argv[4]));
	stations = htons(UDPcount);
	Welcome[0] = 0;
	Welcome[1] = (uint8_t) ((stations & 0xFF));
	Welcome[2] = (uint8_t) ((stations & 0xFF00) >> 8);
	Welcome[3] = (uint8_t) ((multicastAddress & 0xFF000000) >> 24);
	Welcome[4] = (uint8_t) ((multicastAddress & 0xFF0000) >> 16);
	Welcome[5] = (uint8_t) ((multicastAddress & 0xFF00) >> 8);
	Welcome[6] = (uint8_t) ((multicastAddress & 0xFF));
	Welcome[7] = (uint8_t) ((port & 0xFF));
	Welcome[8] = (uint8_t) ((port & 0xFF00) >> 8);
	Welcome[9] = row[0];
	Welcome[10] = col[0];
	udp_channels = (pthread_t*) realloc(udp_channels,
			sizeof(pthread_t) * (UDPcount + 1));
	for (i = 0; i < UDPcount; i++) {
		arg[i].address = multicastAddress + (((i) << 24));
		arg[i].port = port;
		arg[i].name = argv[5 + i];
		if (pthread_create(&udp_channels[i], NULL, udp_channel, (void*) &arg[i])
				!= 0) {
			perror("stinky\n");
			EXIT=1;
		}
	}
	for (i = 0; i < UDPcount; i++) {
		channel[i] = 0;
	}
	for (i = 0; i < client_count; i++) {
		client[i][0] = 0;
		client[i][1] = WAITING;
		client[i][2] = 0;
		client[i][3] = 0;
		client[i][4] = 0;
	}
	if ((basic_TCP = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
		perror("socket failure\n");
		exit(0);
	}
	if (setsockopt(basic_TCP, SOL_SOCKET, SO_REUSEADDR, (char*) &opt,
			sizeof(opt)) < 0) {
		perror("socket setting error\n");
		exit(0);
	}
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = INADDR_ANY;
	address.sin_port = htons(atoi(argv[1]));
	p_arg[0].address = INADDR_ANY;
	p_arg[0].port = (atoi(argv[2]));
	p_arg[1].address = INADDR_ANY;
	p_arg[1].port = htons(atoi(argv[2]));
	if (bind(basic_TCP, (struct sockaddr *) &address, sizeof(address)) < 0) {
		perror("bind error\n");
		exit(0);
	}
	if (listen(basic_TCP, client_count) < 0) {
		perror("listen error\n");
		exit(0);
	}
	addrlen = sizeof(address);
	r_fds=&readfds;
	if(pipe(exitset)<0){
						EXIT=1;
						perror("pipe error\n");
					}
	if(pthread_create(&exit_thread, NULL, exit_trigger, NULL)==-1){

		}

	while (EXIT == 0) {
		FD_ZERO(&readfds);
		FD_SET(basic_TCP, &readfds);

			FD_SET(exitset[0],&readfds);
			if(basic_TCP>exitset[0]){
		maxclient = basic_TCP;
			}else{
				maxclient=exitset[0];
			}
		for (i = 0; i < client_count; i++) {
			clients = client[i][0];
			state = client[i][1];
			if (clients > 0) {
				FD_SET(clients, &readfds);
			}
			if (clients > maxclient) {
				maxclient = clients;
			}
		}

		active = select(maxclient + 1, &readfds, NULL, NULL, NULL);
		if ((active < 0) && (errno != EINTR)) {
			perror("select error\n");
		}
		if (FD_ISSET(basic_TCP, &readfds)) {
			if ((connection = accept(basic_TCP, (struct sockaddr *) &address,
					(socklen_t*) &addrlen)) < 0) {
				perror("accept");
				exit(0);
			}

			for (i = 0; i < client_count; i++) {
				if (client[i][0] == 0) {
					client[i][0] = connection;

					break;
				}
			}
		}
		for (i = 0; i < client_count; i++) {
			clients = client[i][0];
			state = client[i][1];
			if (FD_ISSET(clients, &readfds)) {
				if ((retval = read(clients, clientmessage, 3)) < 0) {
					EXIT=1;
				} else if (retval == 0) {
					close(clients);
					client[i][0] = 0;
					client[i][1] = WAITING;
				} else {
					switch (clientmessage[0]) {
					case 0: //hello
						if (state == WAITING) {
							Welcome[0] = 0;
							if (send(clients, Welcome, 11, 0) != 11) {
								perror("send error\n");
							}
							state = BASIC;
							client[i][1] = BASIC;
						} else {
							//invalid
							Invalidp[0] = 4;
							Invalidp[1] = 13;
							if (send(clients, Invalidp, 2, 0) != 2
									|| send(clients, "Invalid Hello", 13, 0)
											!= 13) {
								perror("send error\n");
							}
							close(client[i][0]);
							client[i][0] = 0;
							client[i][1] = 0;
							if (state == PREMIUM) {
								P_EXIT[client[i][2]] = 1;
								while (P_EXIT[client[i][2]] == 1) {
								}
								pthread_join((premium_channels[client[i][2]]),
										NULL);
								PREMIUM_COUNTER--;
							}
							client[i][2] = 0;
							client[i][3] = 0;
							client[i][4] = 0;
						}
						//printf("success\n");
						break;
					case 1:
						if (state != WAITING) {
							station = ((clientmessage[1] << 8)
									| (clientmessage[2]));
							Announce[0] = 1;
							Announce[1] = row[station];
							Announce[2] = col[station];
							Announce[3] = strlen(argv[5 + station]);
							if(state==PREMIUM){
							client[i][4] = station;
							}else{
							client[i][3] = station;
							}
							if (send(clients, Announce, 4, 0) != 4
									|| send(clients, argv[5 + station],
											strlen(argv[5 + station]), 0)
											!= strlen(argv[5 + station])) {
								perror("send error\n");
							}
							if(state==PREMIUM){
								movies[client[i][2]]=argv[5+station];
							}

						} else {
							//invalid
							Invalidp[0] = 4;
							Invalidp[1] = 11;
							if (send(clients, Invalidp, 2, 0) != 2
									|| send(clients, "State error", 11, 0)
											!= 11) {
								perror("send error\n");
							}
							close(client[i][0]);
							client[i][0] = 0;
							client[i][1] = 0;
							client[i][2] = 0;
							client[i][3] = 0;
						}
						break;
					case 2:
						//gopro
						if (state == BASIC) {
							if (PREMIUM_COUNTER < 2) {
								client[i][2] = PREMIUM_COUNT;
								client[i][1]=PREMIUM;
								state=PREMIUM;
								p_arg[PREMIUM_COUNT].port = (
										p_arg[PREMIUM_COUNT].port);
								p_arg[PREMIUM_COUNT].name =
										arg[client[i][3]].name;
								movies[client[i][2]]=arg[client[i][3]].name;
								p_arg[PREMIUM_COUNT].id = PREMIUM_COUNT;
								done = 0;
								//printf("%d\n", p_arg[PREMIUM_COUNT].port);
								if (pthread_create(
										&premium_channels[PREMIUM_COUNT], NULL,
										premium_connection,
										(void*) &p_arg[PREMIUM_COUNT]) != 0) {
									perror("stinky\n");
									//return -1;
								}

								while (done == 0) {
								}

								Announce[0] = 2;
								Announce[1] = 1;
								Announce[3] = ((p_arg[PREMIUM_COUNT].port)
										& 0xFF00) >> 8;
								Announce[2] = ((p_arg[PREMIUM_COUNT].port)
										& 0xFF);
								PREMIUM_COUNT = 1 - PREMIUM_COUNT;
								PREMIUM_COUNTER++;
							} else {
								Announce[0] = 2;
								Announce[1] = 0;
								Announce[2] = 0;
								Announce[3] = 0;
							}
							if (send(clients, Announce, 4, 0) != 4) {
								perror("send error\n");
							}

						} else {
							Invalidp[0] = 4;
							Invalidp[1] = 11;
							if (send(clients, Invalidp, 2, 0) != 2) {
								perror("send error\n");
							}
						}
						break;
					case 3:
						//speedup
						if (state == PREMIUM) {
							pthread_mutex_lock(&lock);
							play = 0;

							pthread_mutex_unlock(&lock);

							if (clientmessage[1]>=0 && clientmessage[1] <= 100) {
								ack[0] = 3;
																ack[1] = 3;
																if (send(clients, ack, 2, 0) != 2) {
																	perror("send error\n");
																}
								P_SPEED[client[i][2]] =
										(float) (clientmessage[1]) / 100;

							} else {
								Invalidp[0] = 4;
								Invalidp[1] = 13;
								if (send(clients, Invalidp, 2, 0) != 2
										|| send(clients, "Speed Command", 13, 0)
												!= 13) {
									perror("send error\n");
								}
							}
						} else {
							Invalidp[0] = 4;
							Invalidp[1] = 13;
							if (send(clients, Invalidp, 2, 0) != 2
									|| send(clients, "Invalid State", 13, 0)
											!= 13) {
								perror("send error\n");
							}
						}
						pthread_mutex_lock(&lock);
						play = 1;
						pthread_cond_broadcast(&cond);
						pthread_mutex_unlock(&lock);
						break;
					case 4:
						if (state == PREMIUM) {
							pthread_mutex_lock(&lock);
							play = 0;

							pthread_mutex_unlock(&lock);
							while (done != 1) {
							}
							P_EXIT[client[i][2]] = 1;
							ack[0] = 3;
							ack[1] = 4;
							if (send(clients, ack, 2, 0) != 2) {
								perror("send error\n");
							}
							pthread_mutex_lock(&lock);
														play = 1;
														pthread_cond_broadcast(&cond);
														pthread_mutex_unlock(&lock);
							while (P_EXIT[client[i][2]] == 1) {
							}
							pthread_join(premium_channels[client[i][2]], NULL);
							PREMIUM_COUNTER--;
							client[i][1]=BASIC;
							state = BASIC;
							PREMIUM_COUNT=client[i][2];
							client[i][2]=0;
							//client[i][3]=

						} else {
							Invalidp[0] = 4;
							Invalidp[1] = 15;
							if (send(clients, Invalidp, 2, 0) != 2
									|| send(clients, "Invalid Command", 15, 0)
											!= 15) {
								perror("send error\n");
							}
						}
						pthread_mutex_lock(&lock);
						play = 1;
						pthread_cond_broadcast(&cond);
						pthread_mutex_unlock(&lock);
						break;
					default:
						Invalidp[0] = 4;
						Invalidp[1] = 15;
						if (send(clients, Invalidp, 2, 0) != 2
								|| send(clients, "Invalid Command", 15, 0)
										!= 15) {
							perror("send error\n");
						}

						break;
					}
				}
			}
		}
	}
	for (i = 0; i < client_count; i++) {
						clients = client[i][0];
						state = client[i][1];
						if (FD_ISSET(clients, &readfds)) {
	if(PREMIUM_COUNTER>0){

						if(state==PREMIUM){
		pthread_mutex_lock(&lock);
									play = 0;

									pthread_mutex_unlock(&lock);
									while (done != 1) {
									}
									P_EXIT[client[i][2]] = 1;
									ack[0] = 3;
									ack[1] = 4;
									if (send(clients, ack, 2, 0) != 2) {
										perror("send error\n");
									}
									pthread_mutex_lock(&lock);
																play = 1;
																pthread_cond_broadcast(&cond);
																pthread_mutex_unlock(&lock);
									while (P_EXIT[client[i][2]] == 1) {
									}
									pthread_join(premium_channels[client[i][2]], NULL);
									PREMIUM_COUNTER--;
									client[i][1]=BASIC;
									state = BASIC;
									PREMIUM_COUNT=client[i][2];

	}
					}
	close(clients);
						}
	}


						free(row);
						free(col);
						free(arg);



		for (i = 0; i < UDPcount; i++) {
				while(UDP_EXIT<UDPcount){}
				if (pthread_join(udp_channels[i],NULL)
						!= 0) {
					perror("stinky\n");
				}
			}
		free(udp_channels);
		close(exitset[0]);
		close(exitset[1]);

	return 1;
}
