/*
 ============================================================================
 Name        : TCP.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>

#define BFZ 1024
#define BASIC 0
//#define PREMIUM 1
uint16_t PORT3;
//server message structs
typedef struct Welcome {
	uint8_t replyType; //0
	uint16_t numStations;
	uint32_t multicastGroup;
	uint16_t portNumber;
	uint8_t row;
	uint8_t col;
} Welcome;

typedef struct Announce {
	uint8_t replyType; //1
	uint8_t row;
	uint8_t col;
	uint8_t filmNameSize;
	char* filmName; //=(char*)malloc(filmNameSize*sizeof(char));
} Announce;

typedef struct PermitPro {
	uint8_t replyType; //2
	uint8_t permit; // 1 || 0
	uint16_t portNumber; //if permit =1, else portNumber=NULL
} PermitPro;

typedef struct InvalidCommand {
	uint8_t replyType; //3
	uint8_t replyStringSize;
	char replyString; //=(char*)malloc(replyStringSize*sizeof(char));
} InvalidCommand;
//client message structs
typedef struct Command {
	uint8_t commandType; //0 for hello, 2 for GoPro, 4 for Release
	uint16_t reserved; //0
} Command;
typedef struct AskFilm {
	uint8_t commandType; //=1
	uint16_t stationNumber;
} AskFilm;
typedef struct SpeedUp {
	uint8_t commandType; // = 3
	uint16_t speed;

} SpeedUp;
typedef struct view_info {
	int p;
	int a;
	int po;
	int s;
} view_info;
struct arguments {
	uint32_t address;
	uint16_t port;
	uint16_t row;
	uint16_t col;
};

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
int play = 1;
int premium = 0;
int ch = 1;
uint16_t premium_port = 0;
int TCP_address = 0;
int done = 0;
int EXIT = 0;
int Timedout = 0;
int ROW = 0;
int COL = 0;
int UDP_ROW=0;
int UDP_COL=0;
uint32_t UDP_group;
uint32_t UDP_address;
void SetNonBlocking(int fd) {
	int status = fcntl(fd, F_SETFL, fcntl(fd, F_GETFL, 0) | O_NONBLOCK);
	if (status == -1) {
		perror("fcntl\n");
	}
}
void timeout_handler(int signo) {
	if (signo == SIGALRM) {
		Timedout = 1;
	}
}
void* udp_receiver(void* args) {
	struct arguments *arg = (struct arguments*) args;
	int UDPsocket;
	uint16_t port = arg->port;
	//uint32_t address = arg->address;
	uint16_t rows = ROW;
	uint16_t cols = COL;
	uint16_t frame = rows * cols;
	uint16_t size = (cols + 1) * (rows + 1);
	int pr = 0;
	char *bufferfull;
	int count = 0;
	//int error=0;
	int retval;
	int msglen = 1;

	//char **buff;
	struct sockaddr_in serveraddr;
	struct ip_mreq mreq;
	int i = 0;
	int j = 0;
	char c = '\0';
	int bufferoffset = 0;
	bufferfull = (char*) malloc((size + 1) * sizeof(char));
	size_t buffsize = sizeof(bufferfull);
	memset(bufferfull, '\0', sizeof(bufferfull));
	socklen_t socksize = sizeof(serveraddr);
	struct in_addr ip_addr;

	//for premium
	int TCPsocket;
	struct sockaddr_in TCPserveraddr;
	socklen_t TCPsocksize = sizeof(TCPserveraddr);
	ip_addr.s_addr = UDP_group;
	printf("Multicast group: %s\nPort: %d\n\n", inet_ntoa(ip_addr),
			htons(port));

	//printf("%d\n",retval);
	//printf("1\n");
	while (EXIT == 0) {
		if (play) {
			done = 0;
			switch (premium) {
			case 0:
				if (pr == 1) {
					pr = 0;
					close(TCPsocket);
				}
				if (ch == 1) {
					/*if (j > 0) {
					 for (i = 0; i < rows; i++) {
					 printf("\033[1A\033[2K\r"); //delete a row and move the 'cursor' up
					 }
					 j = 0;
					 }*/

					for (i = 0; i < 3; i++) {
						printf("\033[1A\033[2K\r"); //delete a row and move the 'cursor' up
					}
					i = 0;
					ip_addr.s_addr = UDP_group;
					//printf("%d\n", cols);
					printf("Multicast group: %s\nPort: %d\n",
							inet_ntoa(ip_addr), htons(port));
					//printf("%d,%d\n",rows,cols);
					setsockopt(UDPsocket, IPPROTO_IP, IP_DROP_MEMBERSHIP, &mreq,
							sizeof(mreq));
					close(UDPsocket);
					UDPsocket = socket(AF_INET, SOCK_DGRAM, 0);
					if (UDPsocket == -1) {
						printf("cant assign socket\n");
						exit(0);
					}
					//printf("1\n");
					memset(&serveraddr, 0, sizeof(serveraddr));
					serveraddr.sin_family = AF_INET;
					serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
					serveraddr.sin_port = port;
					//printf("%d,", port);
					//printf("%d\n", serveraddr.sin_port);
					if (bind(UDPsocket, (struct sockaddr*) &serveraddr,
							sizeof(serveraddr)) < 0) {
						close(UDPsocket);
						printf("cant bind to socket\n");
						exit(1);
					}
					//printf("%d\n", UDP_group);
					ip_addr.s_addr = UDP_group;
					mreq.imr_multiaddr.s_addr = inet_addr(inet_ntoa(ip_addr));
					mreq.imr_interface.s_addr = INADDR_ANY;
					retval = setsockopt(UDPsocket, IPPROTO_IP,
					IP_ADD_MEMBERSHIP, (char*) &mreq, sizeof(mreq));
					if (retval < 0) {
						perror("setting error\n");
						EXIT = 1;
					}
					pthread_mutex_lock(&lock);
					ch = 0;
					pthread_mutex_unlock(&lock);
				}
				//printf("%d\n",count);
				//for(i=0;i<rows;i++){
				//memset(bufferfull, '\0', sizeof(bufferfull));
				bufferoffset = 0;
				pthread_mutex_lock(&lock);
									rows = ROW;
									cols = COL;

									pthread_mutex_unlock(&lock);
									frame = rows * cols;
									size = ((cols + 1) * (rows + 1) + 1);
									bufferfull = (char*) realloc(bufferfull,
											(size + 1) * sizeof(char));
									buffsize = sizeof(bufferfull);
									memset(bufferfull, '\0', sizeof(bufferfull));
				if ((msglen = recvfrom(UDPsocket, bufferfull,
						(rows * cols) * sizeof(char), 0,
						(struct sockaddr*) &serveraddr, &socksize)) == -1) {
					perror("recv error\n");
					EXIT = 1;
				}
				//printf("%s\n",bufferfull);
				//}
				//if(msglen!=0){
				c = '\0';
				if (msglen > 0) {
					count = 0;
					for (i = 0; i < rows && bufferoffset <= msglen; i++) { //print the frame
						/*printf( "%s",buff[i] );// print a row
						 memset(buff[i],'\0',sizeof(buff[i]));*/
						for (j = 0;
								j <= cols && c != '\n' && bufferoffset <= msglen;
								j++) {
							/*if(bufferfull[i * cols + j]=='\0'){
							 printf(" ");
							 }else{*/

							c = bufferfull[bufferoffset];
							bufferoffset++;
							if (c <= 31) {
								j--;
							}
							if (c != '\n' && c != EOF && c != 10) {
								printf("%c", c);
							} else {
								j++;
								printf("\n");
								count++;
								//printf("\n");
								break;
							}

							/*if(bufferfull[i*cols+j]=='\n'){
							 count++;
							 }*/
							//}
						}

						c = '\0';

						//printf("\n");
						//printf("\n");
					}
					//printf("\n");
					//printf("%s", bufferfull);
					if (count >= rows) {
						count -= rows;
					} else {
						count = 0;
					}
					if (j > 0 || i > 0) {
						for (i = 0; i < rows + count; i++) {
							//printf("%d\n",cols);
							printf("\033[1A\033[2K\r"); //delete a row and move the 'cursor' up
						}
					}
					count = 0;
				} else {
					//printf("%d\n", msglen);
				}
				break;
			case 1:
				//printf("%d\n",pr);
				if (pr == 0) {
					//printf("\n");
					TCPsocket = socket(AF_INET, SOCK_STREAM, 0);
					if (TCPsocket == -1) {
						printf("cant assign socket\n");
						exit(0);
					}

					TCPserveraddr.sin_family = AF_INET;
					TCPserveraddr.sin_addr.s_addr = TCP_address;
					TCPserveraddr.sin_port = premium_port;
					//printf("ffff");
					//printf("connecting: %s:%d\n",inet_ntoa(TCPserveraddr.sin_addr),premium_port);

					if (connect(TCPsocket, (struct sockaddr*) &TCPserveraddr,
							sizeof(TCPserveraddr)) != 0) {
						close(TCPsocket);
						perror("cant connect to socket\n");
						EXIT = 1;
					}
					//SetNonBlocking(TCPsocket);
					pr = 1;

				}
				pthread_mutex_lock(&lock);
				rows = ROW;
				cols = COL;
				//printf("%d,%d\n",rows,cols);
				pthread_mutex_unlock(&lock);
				size = (rows) * (cols);
				bufferfull = (char*) realloc(bufferfull,
						(size + 1) * sizeof(char));
				buffsize = sizeof(bufferfull);
				memset(bufferfull, '\0', sizeof(bufferfull));
				//pthread_mutex_unlock(&lock);
				bufferoffset = 0;

				if ((msglen = recvfrom(TCPsocket, (bufferfull), size, 0,
						(struct sockaddr*) &TCPserveraddr, &TCPsocksize))
						== -1) {
					perror("recv error\n");
					EXIT = 1;
				}
				//printf("%s\n",bufferfull);
				//}
				//if(msglen!=0){
				c = '\0';
				if (msglen > 0) {
					count = 0;
					for (i = 0; i < rows && bufferoffset <= msglen; i++) { //print the frame
						/*printf( "%s",buff[i] );// print a row
						 memset(buff[i],'\0',sizeof(buff[i]));*/
						for (j = 0;
								j <= cols && c != '\n' && bufferoffset <= msglen;
								j++) {
							/*if(bufferfull[i * cols + j]=='\0'){
							 printf(" ");
							 }else{*/

							c = bufferfull[bufferoffset];
							bufferoffset++;
							if (c <= 31) {
								j--;
							}
							if (c != '\n' && c != EOF && c != 10) {
								printf("%c", c);
							} else {
								j++;
								printf("\n");
								count++;
								//printf("\n");
								break;
							}

							/*if(bufferfull[i*cols+j]=='\n'){
							 count++;
							 }*/
							//}
						}

						c = '\0';

						//printf("\n");
						//printf("\n");
					}
					//printf("\n");
					//printf("%s", bufferfull);
					if (count >= rows) {
						count -= rows;
					} else {
						count = 0;
					}
					if ((j > 0 || i > 0)) {
						for (i = 0; i < rows + count; i++) {
							//printf("%d\n",cols);
							printf("\033[1A\033[2K\r"); //delete a row and move the 'cursor' up
						}
					}
					count = 0;
				}
			}
		}

		pthread_mutex_lock(&lock);
		done = 1;

		while (play != 1)
			pthread_cond_wait(&cond, &lock);
		pthread_mutex_unlock(&lock);

	}
	setsockopt(UDPsocket, IPPROTO_IP, IP_DROP_MEMBERSHIP, &mreq, sizeof(mreq));
	//printf("1\n");
	close(UDPsocket);
	if (premium && pr) {
		close(TCPsocket);
	}
	free(bufferfull);
	pthread_mutex_lock(&lock);
	//printf("stuck\n");
	EXIT = 0;
	Timedout = 1;
	pthread_mutex_unlock(&lock);
	/*if(retval!=0){
	 printf("socket error");
	 exit(0);
	 }*/
	return 0;
}
int main(int argc, char **argv) {
	int ji = 3;
	pthread_t view;
	int TCPsocket;
	uint8_t message[3] = { 0 };
	uint8_t permitpro[4] = { 0 };
	uint8_t speed[2] = { 0 };
	int msglen = 1;
	uint8_t buff1[12] = { 0 };
	char sp[4] = { '\0' };
	uint8_t command[3];
	char c[3] = { '\0' };
	size_t len = 3;
	struct sockaddr_in serveraddr;
	int retval;
	int i = 0;
	char* cha = NULL;
	size_t ij = 0;

	struct arguments arg;
	//memset(&UDPserveraddr,0,sizeof(UDPserveraddr));
	TCPsocket = socket(AF_INET, SOCK_STREAM, 0);
	if (TCPsocket == -1) {
		printf("cant assign socket\n");
		exit(0);
	}

	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = inet_addr(argv[1]);
	TCP_address = inet_addr(argv[1]);
	serveraddr.sin_port = htons(atoi(argv[2]));
	//printf("ffff");

	if (connect(TCPsocket, (struct sockaddr*) &serveraddr, sizeof(serveraddr))
			!= 0) {
		close(TCPsocket);
		printf("cant connect to socket\n");
		exit(0);
	}
	//printf("ffff\n");

	command[0] = 0;
	command[1] = 0;
	command[2] = 0;
	//printf("ffff\n");

	retval = send(TCPsocket, command, 3, 0);
	if (retval == -1) {
		perror("send failed\n");
		exit(1);
	}

	//printf("ffff\n");
	if ((msglen = recv(TCPsocket, buff1, 11, 0)) == -1 || msglen != 11) {
		perror("recv error\n");
		exit(1);
	}
	//memcpy(&(PORT3), &buff1[7], 2);
	UDP_group = ((((uint8_t) buff1[3]) << 24) | (((uint8_t) buff1[4]) << 16)
			| (((uint8_t) buff1[5]) << 8) | (((uint8_t) buff1[6]) & 0xff));
	arg.port = ((buff1[8] << 8) | (buff1[7] & 0xff));
	UDP_address = UDP_group;
	//printf("%d\n", PORT3);
	ROW = buff1[9];
	COL = buff1[10];
	if (pthread_create(&view, NULL, udp_receiver, (void*) &arg) != 0) {
		perror("stinky\n");
		return -1;
	}
	while ((Timedout == 0)
			&& ((c[0] != '4' && premium == 0) || (c[0] != '5' && premium == 1))) {

		c[0] = getc(stdin);

		if (c[0] != '\n') {
			getc(stdin);
		}
		for (i = 0; i <= (1 - play) * (6); i++) {
			printf("\033[1A\033[2K\r"); //delete a row and move the 'cursor' up
		}

		//printf("Options:\n1.Change Channel\n2.Ask for premium\n3.Continue\n4.Quit\n");

		//if(c!='\n'){
		//}
		if (premium == 0) {

			switch (c[0]) {

			case '3':
				//printf("CONTINUE\n");
				pthread_mutex_lock(&lock);
				play = 1;
				pthread_cond_broadcast(&cond);
				pthread_mutex_unlock(&lock);
				//printf("\n");

				break;
			case '2':
				message[0] = 2;
				UDP_COL=COL;
				UDP_ROW=ROW;
				send(TCPsocket, message, 3, 0);
				if ((msglen = recv(TCPsocket, permitpro, 4, 0)) == -1) {
					perror("recv error\n");
					exit(1);
				}
				if (permitpro[0] == 2 && permitpro[1] == 1) {
					pthread_mutex_lock(&lock);
					premium = 1;
					premium_port = ((permitpro[3] << 8) | permitpro[2]);
					play = 1;
					pthread_cond_broadcast(&cond);
					pthread_mutex_unlock(&lock);
					//printf("%d\n\n", premium_port);
					//printf("\033[1A\033[2K\r");

				} else {
					c[0] = '4';
					premium = 0;
				}

				break;
			case '1':
				//ch=1;

				i = getline(&cha, &ij, stdin);
				command[0] = 1;
				//printf("\n\n");
				if (i > 2) {
					command[1] = cha[1] - '0';
					command[2] = cha[0] - '0';
				} else {
					command[2] = 0;
					command[2] = cha[0] - '0';
				}
				//printf("ffff\n");
				//printf("%d%d\n", command[1], command[2]);
				retval = send(TCPsocket, command, 3, 0);
				if (retval == -1) {
					perror("send failed\n");
					exit(1);
				}
				command[0] = 0;
				ualarm(300000, 1);
				if ((msglen = recv(TCPsocket, buff1, 4, 0)) == -1
						|| buff1[0] != 1) {
					perror("recv error\n");
					exit(1);
				}
				//printf("1\n\n");
				free(cha);
				cha = NULL;

				cha = (char*) malloc(((buff1[3] + 1) * sizeof(char)));
				memset(cha, '\0', buff1[3] + 1);
				if ((msglen = recv(TCPsocket, cha, buff1[3], 0)) == -1) {
					perror("recv error\n");
					exit(1);
				}
				ualarm(0, 1);
				printf("Movie Name: %s\n\n\n\n\n", cha);
				free(cha);
				cha = NULL;
				break;
			case '0':
				i = getline(&cha, &ij, stdin);
				i = atoi(cha);
				//printf("%d\n", i);
				UDP_group = (UDP_address) + ((i) << 24);
				command[0] = 1;
				//printf("\n\n");
				if (i > 2) {
					command[1] = cha[1] - '0';
					if (command[1] > 3) {
						EXIT = 1;
						printf("Invalid channel\n");
					}
					command[2] = cha[0] - '0';
				} else {
					command[2] = cha[0] - '0';
					command[1] = 0;
				}
				//printf("ffff\n");

				retval = send(TCPsocket, command, 3, 0);
				if (retval == -1) {
					perror("send failed\n");
					exit(1);
				}
				command[0] = 0;
				ualarm(300000, 0);
				if ((msglen = recv(TCPsocket, buff1, 4, 0)) == -1) {
					perror("recv error\n");
					exit(1);
				}
				ualarm(0, 0);
				free(cha);
				cha = NULL;
				pthread_mutex_lock(&lock);
				ROW = buff1[1];
				COL = buff1[2];
				ch = 1;
				play = 1;
				pthread_cond_broadcast(&cond);
				pthread_mutex_unlock(&lock);
				cha = (char*) malloc(((buff1[3] + 1) * sizeof(char)));
				memset(cha, '\0', buff1[3] + 1);
				if ((msglen = recv(TCPsocket, cha, buff1[3], 0)) == -1) {
					perror("recv error\n");
					exit(1);
				}
				free(cha);
				cha = NULL;
				break;
			default:
				pthread_mutex_lock(&lock);
				play = 0;

				pthread_mutex_unlock(&lock);
				while (done != 1) {
				}
				printf(
						"Options:\n0.Change Channel\n1.Ask about channel\n2.Ask for premium\n3.Continue\n4.Quit\n");
				//pthread_mutex_lock(&lock);

				//pthread_mutex_unlock(&lock);
				break;
			}
		} else {

			switch (c[0]) {
			case '1':
				i = getline(&cha, &ij, stdin);
				i = atoi(cha);
				//printf("%d\n", i);
				command[0] = 1;
				//printf("\n\n");
				if (i > 2) {
					command[1] = cha[1] - '0';
					if (command[1] > 3) {
						EXIT = 1;
						printf("Invalid channel\n");
					}
					command[2] = cha[0] - '0';
				} else {
					command[2] = cha[0] - '0';
					command[1] = 0;
				}
				//printf("ffff\n");

				retval = send(TCPsocket, command, 3, 0);
				if (retval == -1) {
					perror("send failed\n");
					exit(1);
				}
				command[0] = 0;
				ualarm(300000, 0);
				if ((msglen = recv(TCPsocket, buff1, 4, 0)) == -1) {
					perror("recv error\n");
					exit(1);
				}
				ualarm(0, 0);
				free(cha);
				cha = NULL;
				cha = (char*) malloc(((buff1[3] + 1) * sizeof(char)));
				memset(cha, '\0', buff1[3] + 1);
				if ((msglen = recv(TCPsocket, cha, buff1[3], 0)) == -1) {
					perror("recv error\n");
					exit(1);
				}
				printf("Movie Name:%s\n", cha);
				free(cha);
				cha = NULL;
				pthread_mutex_lock(&lock);
				ROW = buff1[1];
				COL = buff1[2];
				play = 1;
				pthread_cond_broadcast(&cond);
				pthread_mutex_unlock(&lock);
				//printf("\033[1A\033[2K\r"); //delete a row and move the 'cursor' up
				break;
			case '2':
				speed[0] = 3;
				if ((msglen = getline((char**) &sp, &len, stdin)) == -1) {
					perror("bad input");
				}
				speed[1] = atoi(sp);
				send(TCPsocket, speed, 2, 0);
				ualarm(300000, 0);
				if ((msglen = recv(TCPsocket, speed, 2, 0)) == -1
						|| msglen != 2) {
					perror("recv error\n");
					exit(1);
				}
				ualarm(0, 0);
				if (speed[0] == 3 && speed[1] == 3) {
					pthread_mutex_lock(&lock);
					play = 1;
					pthread_cond_broadcast(&cond);
					pthread_mutex_unlock(&lock);

				}
				printf("\033[1A\033[2K\r");
				break;
			case '3':
				//printf("CONTINUE\n");
				pthread_mutex_lock(&lock);
				play = 1;
				//printf("\n");
				pthread_cond_broadcast(&cond);
				pthread_mutex_unlock(&lock);
				break;
			case '4':
				message[0] = 4;
				message[1]=0;
				message[2]=0;
				send(TCPsocket, message, 3, 0);
				speed[0]=0;
				speed[1]=0;
				if ((msglen = recv(TCPsocket, speed, 2, 0)) == -1
						|| msglen != 2) {
					perror("recv error\n");
					c[0] = '5';
				}
				if (speed[0] == 3 && speed[1] == 4) {
					pthread_mutex_lock(&lock);
					premium = 0;
					ROW=UDP_ROW;
					COL=UDP_COL;
					c[0] = '\0';
					play = 1;
					pthread_cond_broadcast(&cond);
					pthread_mutex_unlock(&lock);

					//while (done != 1) {
					//}
					/*=printf(
					 "Options:\n1.Change Channel\n2.Ask for premium\n3.Continue\n4.Quit\n");
					 */
				}
				break;
			default:
				pthread_mutex_lock(&lock);
				play = 0;

				pthread_mutex_unlock(&lock);
				while (done != 1) {
				}
				printf(
						"Options:\n1.Change Film\n2.Change Speed\n3.Continue\n4.Go back to basic\n5.Quit\n");
				//pthread_mutex_lock(&lock);

				//pthread_mutex_unlock(&lock);
				break;
			}

		}

	}
	pthread_mutex_lock(&lock);
	EXIT = 1;
	play = 1;
	pthread_cond_broadcast(&cond);
	pthread_mutex_unlock(&lock);
	while (EXIT == 1) {

	}
	return pthread_join(view, NULL);
	close(TCPsocket);

	return 0;
}

