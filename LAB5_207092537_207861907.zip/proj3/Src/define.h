//hi
#define HIGH	2298
#define LOW		1798
