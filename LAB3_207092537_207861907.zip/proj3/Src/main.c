
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2020 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f1xx_hal.h"

/* USER CODE BEGIN Includes */

#include	"define.h"
#include 	"stdio.h"
#include	"stdlib.h"


/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
int phy_to_dll_rx_bus_valid=0;
int dll_to_phy_tx_bus_valid=0;
int dll_to_phy_tx_bus_valid_check=0;
int phy_tx_busy=0;
int tx_data=0;
uint16_t	txShiftCount=0;//keeps track of the current bit pin for TX
uint16_t	rxShiftCount;//keeps track of the current bit pin for TX
int prevRX=0;
int prevTX=0;
uint8_t check=0;
int prevINTC=0;
int curr=0;
uint8_t interfaceClock=0;
uint8_t isAlive=0;
uint8_t Busy=0;
uint8_t chk=0;
int recievecheck=2;
int txbustransfer=0;
int rxbustransfer=0;
int rxbus=phy_rx_data_bus_bit_0_Pin|phy_rx_data_bus_bit_1_Pin|phy_rx_data_bus_bit_2_Pin|phy_rx_data_bus_bit_3_Pin|phy_rx_data_bus_bit_4_Pin|phy_rx_data_bus_bit_5_Pin|phy_rx_data_bus_bit_6_Pin|phy_rx_data_bus_bit_7_Pin;
int txbus=phy_tx_data_bus_bit_0_Pin|phy_tx_data_bus_bit_1_Pin|phy_tx_data_bus_bit_2_Pin|phy_tx_data_bus_bit_3_Pin|phy_tx_data_bus_bit_4_Pin|phy_tx_data_bus_bit_5_Pin|phy_tx_data_bus_bit_6_Pin|phy_tx_data_bus_bit_7_Pin;
int GPIOB_VALID_BUSY=pin_phy_tx_busy_Pin|phy_rx_data_bus_valid_Pin;
int* GPIOA_TX_BUS=(int*)(GPIOA_BASE|0x8);//IDR
int* GPIOB_RX_BUS=(int*)(GPIOB_BASE|0xC);//ODR
int TX_BUS=0;
int RX_BUS=0;
int currentBitTX=0;//keeps track of the current bit for TX
int syncBitCounterTX=0;
int DebugSample=0;
int syncBitCounterRX=0;
int MidBitTX=0;
int MidBitRX=0;
int CurrentBitRX=0;//keeps track of the current bit for RX
int Sample;
int Sample1;
int Sample2;
int Sample3;
int Sample4;
int Sample5;
int	SampleCount;
uint32_t CountTicks;
int secondrise=0;
int CLOCKFREQUENCYRX;
int CLOCKFREQUENCYIF;
int tries=2;
int SampleTaken=0;
int TX_clock=0;
int RX_clock=0;
int rx_delay=1;
int rx_error_flag;//0 means its okay, 1 means try to fix, 2 means unfixable
int rx_state=0;
int tx_busy_buffer;
int rx_secondrise;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM4_Init(void);
static void MX_ADC1_Init(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
int LogicalRX(int countdown);
void LogicalTX(int i);
void phy_TX(void);
void rx_read(void);
void phy_RX(void);
void phy_layer(void);
void interface(void);
/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

/*
void dll_RX(){
	if(phy_to_dll_rx_bus_valid){
		rx_data=phy_to_dll_rx_bus;
		phy_to_dll_rx_bus=0;
		phy_to_dll_rx_bus_valid=0;
	}
}

void dll_TX(){
	if((dll_to_phy_tx_bus_valid==0) && (phy_tx_busy==0)){
		if(!delay){
			dll_to_phy_tx_bus=tx_data;
			dll_to_phy_tx_bus_valid=1;
			phy_tx_busy=1;
			delay=rand()%9;
		}else if(delay>0){
			delay--;
		}
	}
}
*/
int LogicalRX(int countdown){//CHANGE TO READ ADC AS IN THE PRESENTATION
	//sample the clock
	int result=0;
	
	//HAL_TIM_Base_Start_IT(&htim2);
	//HAL_TIM_Base_Stop_IT(&htim2);
	if((Sample1>=HIGH && Sample2>=HIGH && Sample4<=LOW && Sample5<=LOW) || (Sample1<=LOW && Sample2<=LOW && Sample4>=HIGH && Sample5>=HIGH)){// if we got a logical input
		CurrentBitRX=(Sample1>=HIGH);//Thanks for the tip 
		CurrentBitRX<<=rxShiftCount;
		tries=2;
		return 1;
	}else if(rx_error_flag==2){
						HAL_TIM_Base_Stop_IT(&htim4);
						rx_delay = 1;
						CountTicks=0;
						phy_to_dll_rx_bus_valid=0;
						rxShiftCount=0;
						syncBitCounterRX=0;
						RX_BUS=0;
							rx_state=1;
							rx_error_flag=0;
						__HAL_TIM_SET_COUNTER(&htim4,0);
						__HAL_TIM_SET_AUTORELOAD(&htim4,65535);
						}else{//tells it to try to fix the sample
							SampleCount=6;
							rx_error_flag=1;
						}

	return result;//check issues with idle later
}

void LogicalTX(int i){// 1 is low, 2 is high, 3 is idle
	switch(i){
		case 1:
			tx_data=0;
			HAL_GPIO_WritePin(C_GPIO_Port,C_Pin,GPIO_PIN_SET);
			HAL_GPIO_WritePin(B_GPIO_Port,B_Pin,GPIO_PIN_RESET);
			break;
		case 2:
			tx_data=1;
			HAL_GPIO_WritePin(C_GPIO_Port,C_Pin,GPIO_PIN_SET);
			HAL_GPIO_WritePin(B_GPIO_Port,B_Pin,GPIO_PIN_SET);
			break;
		case 3:
			HAL_GPIO_WritePin(C_GPIO_Port,C_Pin,GPIO_PIN_RESET);
			break;
		}
}

void phy_TX(void){
	if (phy_tx_busy || dll_to_phy_tx_bus_valid_check){
	if(phy_tx_busy==0 && tx_busy_buffer==1){
					HAL_TIM_Base_Start_IT(&htim2);
					phy_tx_busy=1;
					dll_to_phy_tx_bus_valid=0;
					dll_to_phy_tx_bus_valid_check=0;
					prevTX=0;
					txShiftCount=0;
	}else{
		tx_busy_buffer=1;
	}
	if(TX_clock==1 && TX_clock!=prevTX){//interface clock
			prevTX=TX_clock;
			if(syncBitCounterTX<3){
				phy_tx_busy=1;
					LogicalTX(2);
					syncBitCounterTX++;
//				LogicalTX(2);
		}else if(txShiftCount<8){//check that we have bits left on the bus
			//if(MidBitTX==0){
				currentBitTX=TX_BUS&1;
				TX_BUS>>=1;
			//}
			switch(currentBitTX){
				case 1:
					//if(MidBitTX==0){
						LogicalTX(2);
				/*	//	MidBitTX=1;
					//}else{
						//LogicalTX(1);
					//	MidBitTX=0;*/
						txShiftCount++;
/*					//}
					//LogicalTX(2);
				//	txShiftCount<<=1;*/
				break;
				case 0:
					//if(MidBitTX==0){
						LogicalTX(1);
/*				//		MidBitTX=1;
				//	}else{
					//	LogicalTX(2);
					//	MidBitTX=0;*/
						txShiftCount++;
/*					//}
//					LogicalTX(1);
	//				txShiftCount<<=1;*/
				break;
			}
		}else{
/*			txShiftCount=0;
			phy_tx_busy=0;
			syncBitCounterTX=0;
			TX_BUS=0;
			HAL_TIM_Base_Stop_IT(&htim2);
			TX_clock=0*/
			}
		}else if(TX_clock==0 && TX_clock!=prevTX){
			prevTX=TX_clock;
			HAL_GPIO_WritePin(C_GPIO_Port,C_Pin,GPIO_PIN_SET);
			HAL_GPIO_TogglePin(B_GPIO_Port,B_Pin);
			tx_data=1-tx_data;
		}
	}

}

void rx_read(void){
	if(Sample>=HIGH && MidBitRX==0){
					HAL_TIM_Base_Start_IT(&htim4);
					MidBitRX=1;
				}else if(Sample<=LOW && MidBitRX==1){
					HAL_TIM_Base_Stop_IT(&htim4);
					CountTicks+=__HAL_TIM_GET_COUNTER(&htim4);
					syncBitCounterRX++;
					MidBitRX=0;
					__HAL_TIM_SET_COUNTER(&htim4, 0);

				}else if (Sample>=LOW && Sample<=HIGH){
						HAL_TIM_Base_Stop_IT(&htim4);
						rx_delay = 1;
						CountTicks=0;
						phy_to_dll_rx_bus_valid=0;
						rxShiftCount=0;
						syncBitCounterRX=0;
						RX_BUS=0;
						rx_error_flag=0;
						TIM4->CNT = 0;
						TIM4->ARR = 65535;
				}
}
void phy_RX(void){//TURN OFF THE CLOCK
//	DebugSample=0;
//chk=HAL_GPIO_ReadPin(pin_interface_clock_GPIO_Port,pin_interface_clock_Pin);
	//if((TX_clock==0) && (TX_clock!=prevRX)){
		while (HAL_ADC_PollForConversion(&hadc1, 5) != HAL_OK) {}
		Sample=HAL_ADC_GetValue(&hadc1);
		SampleTaken=1;
			switch(rx_state){
				case 0:
		if(syncBitCounterRX<=3){	
		switch(syncBitCounterRX){
			case 0:
				rx_read();
			break;
			case 1:
				rx_read();
			break;
			case 2:
				rx_read();
				//CountTicks=(2000000/((__HAL_TIM_GET_COUNTER(&htim4))/72))-1;
				//__HAL_TIM_SET_PRESCALER(&htim3,CountTicks);
			break;
			case 3:
				CountTicks /= 9;
			__HAL_TIM_SET_AUTORELOAD(&htim4,CountTicks);
			rx_state=2;
				syncBitCounterRX++;
				rxShiftCount=0;
				CountTicks=0;
			  //htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
				phy_to_dll_rx_bus_valid=0;
				RX_BUS=0;
				SampleCount=1;
				HAL_TIM_Base_Start_IT(&htim4);
			break;
			
		}
	}
		break;
			case 2:
//		if(TX_clock==1 && TX_clock!=prevTX){
			if(rx_error_flag!=1){
				if(SampleCount==6){
					if(LogicalRX(tries)){// if we got a logical input
						tries=2;
						RX_BUS|=(CurrentBitRX);
						rxShiftCount++;
						CurrentBitRX=0;
						DebugSample=0;
						rx_error_flag=0;
						SampleCount=1;
						if (rxShiftCount==8){
							HAL_TIM_Base_Stop_IT(&htim4);
							rx_state=1;
							rx_delay = 1;
							rxShiftCount=0;
							syncBitCounterRX=0;
							phy_to_dll_rx_bus_valid=1;
							__HAL_TIM_SET_AUTORELOAD(&htim4,65535);
						}
					}
				}
					/*if(DebugSample<2){
						
					}else{
						
					
				}*/
			}
				break;
			case 1:
				if(Sample>=LOW && Sample<=HIGH){
					rx_secondrise=1;
				}
				if(Sample>=HIGH && rx_secondrise==1){
					rx_state=0;
					rx_secondrise=0;
				}
			break;
		}
	}
		
//	}else{
		
//		}
//	}

/*
void dll_layer(){
	dll_TX();
	dll_RX();
}
*/

void phy_layer(void){
	phy_TX();
	phy_RX();
}

void interface(void){
	//IgnoreSignal=0;
	curr=HAL_GPIO_ReadPin(pin_interface_clock_GPIO_Port,pin_interface_clock_Pin);
//	interfaceClock=curr;
	txbustransfer=0;
	rxbustransfer=0;
	if(curr!=prevINTC){
		if(curr==1){
			if(phy_to_dll_rx_bus_valid==1){
				HAL_GPIO_WritePin(phy_rx_data_bus_valid_GPIO_Port,phy_rx_data_bus_valid_Pin,GPIO_PIN_SET);
				rxbustransfer=RX_BUS;
				rxbustransfer<<=8;
				rxbustransfer|=((*GPIOB_RX_BUS)&(0xFFFF00FF));
				*GPIOB_RX_BUS=rxbustransfer;
				RX_BUS=0;
				phy_to_dll_rx_bus_valid=0;
			}else{
				HAL_GPIO_WritePin(phy_rx_data_bus_valid_GPIO_Port,phy_rx_data_bus_valid_Pin,GPIO_PIN_RESET);

			}
			if(phy_tx_busy==1){
				HAL_GPIO_WritePin(pin_phy_tx_busy_GPIO_Port,pin_phy_tx_busy_Pin,GPIO_PIN_SET);
			}else{
				HAL_GPIO_WritePin(pin_phy_tx_busy_GPIO_Port,pin_phy_tx_busy_Pin,GPIO_PIN_RESET);
			}
		}else{
			if(phy_tx_busy==0){
				dll_to_phy_tx_bus_valid=HAL_GPIO_ReadPin(pin_phy_tx_busy_GPIO_Port,phy_tx_data_bus_valid_Pin);
				if(dll_to_phy_tx_bus_valid==1){
					TX_BUS=((*GPIOA_TX_BUS)&txbus);
					dll_to_phy_tx_bus_valid_check=1;
				}
			}
//			isAlive=HAL_GPIO_ReadPin(pin_phy_alive_GPIO_Port,pin_phy_alive_Pin);
//			Busy=HAL_GPIO_ReadPin(pin_phy_tx_busy_GPIO_Port,pin_phy_tx_busy_Pin);
		}
	}
	prevINTC=curr;
	
	
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  *
  * @retval None
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM3_Init();
  MX_TIM2_Init();
  MX_TIM4_Init();
  MX_ADC1_Init();
  /* USER CODE BEGIN 2 */
	HAL_ADC_Start(&hadc1);
	HAL_TIM_Base_Start_IT(&htim3);
//	HAL_TIM_Base_Start_IT(&htim2);
	//HAL_TIM_Base_Start_IT(&htim4);
//	HAL_TIM_Base_Start_IT(&htim4);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,GPIO_PIN_SET);

			

  while (1){
//		dll_layer();
		phy_layer();
		interface();
		
		
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
		
  }
  /* USER CODE END 3 */

}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_PeriphCLKInitTypeDef PeriphClkInit;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* ADC1 init function */
static void MX_ADC1_Init(void)
{

  ADC_ChannelConfTypeDef sConfig;

    /**Common config 
    */
  hadc1.Instance = ADC1;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure Regular Channel 
    */
  sConfig.Channel = ADC_CHANNEL_8;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM2 init function */
static void MX_TIM2_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 35999;
  htim2.Init.CounterMode = TIM_COUNTERMODE_DOWN;
  htim2.Init.Period = 10;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM3 init function */
static void MX_TIM3_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 35999;
  htim3.Init.CounterMode = TIM_COUNTERMODE_DOWN;
  htim3.Init.Period = 10;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM4 init function */
static void MX_TIM4_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 2999;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 65535;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, B_Pin|C_Pin|phy_tx_data_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, phy_rx_data_bus_bit_2_Pin|phy_rx_data_bus_bit_3_Pin|phy_rx_data_bus_bit_4_Pin|phy_rx_data_bus_bit_5_Pin 
                          |phy_rx_data_bus_bit_6_Pin|phy_rx_data_bus_bit_7_Pin|phy_tx_data_bus_valid_Pin|pin_interface_clock_Pin 
                          |pin_phy_alive_Pin|pin_phy_tx_busy_Pin|phy_rx_data_bus_valid_Pin|phy_rx_data_bus_bit_0_Pin 
                          |phy_rx_data_bus_bit_1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : B_Pin C_Pin */
  GPIO_InitStruct.Pin = B_Pin|C_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : phy_tx_data_Pin */
  GPIO_InitStruct.Pin = phy_tx_data_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(phy_tx_data_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : phy_tx_data_bus_bit_0_Pin phy_tx_data_bus_bit_1_Pin phy_tx_data_bus_bit_2_Pin phy_tx_data_bus_bit_3_Pin 
                           phy_tx_data_bus_bit_4_Pin phy_tx_data_bus_bit_5_Pin phy_tx_data_bus_bit_6_Pin phy_tx_data_bus_bit_7_Pin */
  GPIO_InitStruct.Pin = phy_tx_data_bus_bit_0_Pin|phy_tx_data_bus_bit_1_Pin|phy_tx_data_bus_bit_2_Pin|phy_tx_data_bus_bit_3_Pin 
                          |phy_tx_data_bus_bit_4_Pin|phy_tx_data_bus_bit_5_Pin|phy_tx_data_bus_bit_6_Pin|phy_tx_data_bus_bit_7_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : phy_rx_data_bus_bit_2_Pin phy_rx_data_bus_bit_3_Pin phy_rx_data_bus_bit_4_Pin phy_rx_data_bus_bit_5_Pin 
                           phy_rx_data_bus_bit_6_Pin phy_rx_data_bus_bit_7_Pin pin_interface_clock_Pin pin_phy_alive_Pin 
                           pin_phy_tx_busy_Pin phy_rx_data_bus_valid_Pin phy_rx_data_bus_bit_0_Pin phy_rx_data_bus_bit_1_Pin */
  GPIO_InitStruct.Pin = phy_rx_data_bus_bit_2_Pin|phy_rx_data_bus_bit_3_Pin|phy_rx_data_bus_bit_4_Pin|phy_rx_data_bus_bit_5_Pin 
                          |phy_rx_data_bus_bit_6_Pin|phy_rx_data_bus_bit_7_Pin|pin_interface_clock_Pin|pin_phy_alive_Pin 
                          |pin_phy_tx_busy_Pin|phy_rx_data_bus_valid_Pin|phy_rx_data_bus_bit_0_Pin|phy_rx_data_bus_bit_1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : phy_tx_data_bus_valid_Pin */
  GPIO_InitStruct.Pin = phy_tx_data_bus_valid_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(phy_tx_data_bus_valid_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  file: The file name as string.
  * @param  line: The line in file as a number.
  * @retval None
  */
void _Error_Handler(char *file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
