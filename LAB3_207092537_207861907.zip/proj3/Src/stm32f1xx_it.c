/**
  ******************************************************************************
  * @file    stm32f1xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  *
  * COPYRIGHT(c) 2020 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"
#include "stm32f1xx.h"
#include "stm32f1xx_it.h"

/* USER CODE BEGIN 0 */
#include	"define.h"
#include 	"stdio.h"
#include	"stdlib.h"
int tick=0;
int checkpin=(uint8_t) GPIO_PIN_SET;
extern int rxShiftCount;
extern int syncBitCounterTX;
extern int CurrentBitRX;
extern int tx_busy_buffer;
extern int rx_error_flag;
extern int phy_to_dll_rx_bus_valid;
extern int	SampleCount;
extern int Sample;
extern int interfaceClock;
extern int Sample1;
extern int Sample2;
extern int Sample3;
extern int Sample4;
extern int Sample5;
extern int SampleTaken;
extern ADC_HandleTypeDef hadc1;
extern int TX_clock;
extern int RX_clock;
extern int prevRX;
extern int rx_delay;
extern uint16_t	txShiftCount;
extern int dll_to_phy_tx_bus_valid;
extern int prevTX;
extern int	tries;
extern int DebugSample;
extern int phy_tx_busy;

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim4;

/******************************************************************************/
/*            Cortex-M3 Processor Interruption and Exception Handlers         */ 
/******************************************************************************/

/**
* @brief This function handles Non maskable interrupt.
*/
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */

  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
* @brief This function handles Hard fault interrupt.
*/
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
  /* USER CODE BEGIN HardFault_IRQn 1 */

  /* USER CODE END HardFault_IRQn 1 */
}

/**
* @brief This function handles Memory management fault.
*/
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
  /* USER CODE BEGIN MemoryManagement_IRQn 1 */

  /* USER CODE END MemoryManagement_IRQn 1 */
}

/**
* @brief This function handles Prefetch fault, memory access fault.
*/
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
  /* USER CODE BEGIN BusFault_IRQn 1 */

  /* USER CODE END BusFault_IRQn 1 */
}

/**
* @brief This function handles Undefined instruction or illegal state.
*/
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
  /* USER CODE BEGIN UsageFault_IRQn 1 */

  /* USER CODE END UsageFault_IRQn 1 */
}

/**
* @brief This function handles System service call via SWI instruction.
*/
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
* @brief This function handles Debug monitor.
*/
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
* @brief This function handles Pendable request for system service.
*/
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
* @brief This function handles System tick timer.
*/
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  HAL_SYSTICK_IRQHandler();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32F1xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32f1xx.s).                    */
/******************************************************************************/

/**
* @brief This function handles TIM2 global interrupt.
*/
void TIM2_IRQHandler(void)
{
  /* USER CODE BEGIN TIM2_IRQn 0 */

  /* USER CODE END TIM2_IRQn 0 */
  HAL_TIM_IRQHandler(&htim2);
  /* USER CODE BEGIN TIM2_IRQn 1 */
	if(txShiftCount<8){
		TX_clock=1-TX_clock;
//		prevTX=TX_clock;
	}else if(txShiftCount==8){
		txShiftCount++;
		TX_clock=0;
	}else{
		tx_busy_buffer=0;
		dll_to_phy_tx_bus_valid=0;
		phy_tx_busy=0;
		prevTX=0;
		txShiftCount=0;
		syncBitCounterTX=0;
		HAL_GPIO_WritePin(C_GPIO_Port,C_Pin, GPIO_PIN_RESET);
		HAL_TIM_Base_Stop_IT(&htim2);
	}
  /* USER CODE END TIM2_IRQn 1 */
}

/**
* @brief This function handles TIM3 global interrupt.
*/
void TIM3_IRQHandler(void)
{
  /* USER CODE BEGIN TIM3_IRQn 0 */
	//HAL_GPIO_TogglePin(GPIOC,13);
	//tick=rand()%10+1;
  /* USER CODE END TIM3_IRQn 0 */
  HAL_TIM_IRQHandler(&htim3);
  /* USER CODE BEGIN TIM3_IRQn 1 */
	HAL_GPIO_TogglePin(pin_interface_clock_GPIO_Port,pin_interface_clock_Pin);
	interfaceClock=HAL_GPIO_ReadPin(pin_interface_clock_GPIO_Port,pin_interface_clock_Pin);
  /* USER CODE END TIM3_IRQn 1 */
}

/**
* @brief This function handles TIM4 global interrupt.
*/
void TIM4_IRQHandler(void)
{
  /* USER CODE BEGIN TIM4_IRQn 0 */
	
  /* USER CODE END TIM4_IRQn 0 */
  HAL_TIM_IRQHandler(&htim4);
  /* USER CODE BEGIN TIM4_IRQn 1 */
	
	/*if(RX_clock<5){
		if(SampleTaken){
			switch(SampleCount){
				case 1:
					Sample1=0;
					Sample2=0;
					Sample3=0;
					Sample4=0;
					Sample5=0;
					Sample1=Sample;
					SampleCount++;
					SampleTaken=0;
				break;
				case 2:
					Sample2=Sample;
					SampleCount++;
					SampleTaken=0;
				break;
				case 3:
					Sample3=Sample;
					SampleCount++;
					SampleTaken=0;

				break;
				case 4:
					Sample4=Sample;
					SampleCount++;
					SampleTaken=0;

				break;
				case 5:
					Sample5=Sample;
					SampleCount++;
					SampleTaken=0;
				break;
				case 0:
					SampleCount++;
					SampleTaken=0;

				break;
				default:
					SampleTaken=0;

				break;
			}
		}
		RX_clock++;
	}else{
		RX_clock=0;
	}*/
	
	if(rx_delay){
		if(rx_delay>2){
			rx_delay=0;
		}else{
			rx_delay++;
		}
	}else{
	if (SampleTaken){
			switch(SampleCount){
				case 1:
					Sample1=Sample;
					SampleCount++;
//					SampleTaken=0;
				break;
				case 2:

				Sample2=Sample;
					SampleCount++;
//					SampleTaken=0;
				break;
				case 3:

				Sample3=Sample;
					SampleCount++;
//					SampleTaken=0;

				break;
				case 4:

				Sample4=Sample;
					SampleCount++;
//					SampleTaken=0;

				break;
				case 5:
		
				Sample5=Sample;
					SampleCount++;
//					SampleTaken=0;
				break;
				case 0:
					SampleCount++;
//					SampleTaken=0;

				break;
				default:
					if(rx_error_flag==1){// drops the first sample and replaces the final one
						Sample1=Sample2;
						Sample2=Sample3;
						Sample3=Sample4;
						Sample4=Sample5;
						Sample5=LOW-1;
						if(Sample>=HIGH){
							Sample5=Sample;
						}
						if(tries>0){
							tries--;
							rx_error_flag=2;
						}else{
							rx_error_flag=2;
							SampleTaken=0;
						}
				break;
					
				}
			}
		}
	}
  /* USER CODE END TIM4_IRQn 1 */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
